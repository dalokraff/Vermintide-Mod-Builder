--
-- Registers the endurance badge pickups.
--

local ModEnduranceBadges = {}

local endurance_badge_definitions = {
	{ pickup = "endurance_badge_01", unit = "units/props/endurance_badges/prop_endurance_badge_01", mission = "endurance_badge_01_mission" },
	{ pickup = "endurance_badge_02", unit = "units/props/endurance_badges/prop_endurance_badge_02", mission = "endurance_badge_02_mission" },
	{ pickup = "endurance_badge_03", unit = "units/props/endurance_badges/prop_endurance_badge_03", mission = "endurance_badge_03_mission" },
	{ pickup = "endurance_badge_04", unit = "units/props/endurance_badges/prop_endurance_badge_04", mission = "endurance_badge_04_mission" },
	{ pickup = "endurance_badge_05", unit = "units/props/endurance_badges/prop_endurance_badge_05", mission = "endurance_badge_05_mission" },
}

local function add_to_network_lookup(lookup, value)
	if not rawget(lookup, value) then
		local index = #lookup + 1
		lookup[index] = value
		lookup[value] = index
	end
end

function ModEnduranceBadges:init(reload_data)
	for _, def in ipairs(endurance_badge_definitions) do
		add_to_network_lookup(NetworkLookup.husks, def.unit)
		add_to_network_lookup(NetworkLookup.pickup_names, def.pickup)
		--add_to_network_lookup(NetworkLookup.mission_names, def.mission) -- Disabled.

		local pup_settings = {
			debug_pickup_category = "special",
			hud_description = "interaction_endurance_badge",
			individual_pickup = false,
			local_pickup_sound = false,
			--mission_name = def.mission, -- Disabled.
			only_once = true,
			pickup_sound_event = "Play_hud_pickup_badge",
			spawn_weighting = 0,
			type = "endurance_badge",
			unit_name = def.unit,
		}
		Pickups.special[def.pickup] = pup_settings
		AllPickups[def.pickup] = pup_settings
	end
end

return ModEnduranceBadges