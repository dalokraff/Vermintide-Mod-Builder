local VideoTest = VideoTest or {}

function VideoTest:init(reload_data)
	if reload_data and reload_data.world_created then
		self:on_game_state_changed("exit", "StateSplashScreen")
	end
end

function VideoTest:on_game_state_changed(status, state_name)
	if state_name == "StateSplashScreen" and status == "exit" then
		Managers.mod:print("info", "Loading streamable test GUI")
		local world = Managers.world:create_world("streamable_test", GameSettingsDevelopment.default_environment, nil, 999, Application.DISABLE_APEX_CLOTH)
		self._world = world
		
		local loop = false
		self._video_player = World.create_video_player(world, "video/streamable_test", loop)
		
		self._gui = World.create_screen_gui(world, 20, 100, "scale", 0.2, 0.2, "material", "video/streamable_test", "immediate")
		
		self._viewport = ScriptWorld.create_viewport(world, "streamable_test", "overlay", 999)
	end
end

function VideoTest:update()
	if self._gui then
		local w, h = Gui.resolution(self._viewport)
		Gui.video(self._gui, "streamable_test", self._video_player, Vector3(0,0, 10), Vector2(w-10,h-10))
		
		Gui.rect(self._gui, Vector3(0,0,0), Vector2(w, h), Color(150, 255,0,0))
	end
end

function VideoTest:on_reload()
	if self._world then
		return {world_created=true}
	end
end

function VideoTest:on_unload()
	if self._world then
		Managers.world:destroy_world("streamable_test")
	end
end

return VideoTest