PhysX is used to export physics setups from Maya and Max. It's the only way to create physics setups with constraints, like ragdolls and hanging props.

The plugins can be downloaded from Nvidia:
https://developer.nvidia.com/gameworksdownload and search for "physx 3-4-2".
Nvidia stopped supporting PhysX in 2018, so the available plugins for download on their site are these:
- Maya 2015-2018
- Maya LT 2018-2019
- 3DSMax 2015-2019

For newer Maya plugins there is another online resource that has them available, and that is the Golaem crowd simulator.
https://golaem.com/content/doc/golaem-crowd-documentation/cloth-faq
They have an installation guide and currently provides plugins for:
- Maya 2018-2024
