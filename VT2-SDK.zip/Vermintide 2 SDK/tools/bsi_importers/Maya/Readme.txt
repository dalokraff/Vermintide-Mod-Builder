Readme for Maya Bsi importer

Installation:
1: Copy the bsi_importer.py script into the maya script folder.
2: In Maya, open script editor on a Python tab.
3: Add the following text:
import bsi_importer
bsi_importer.importBSI()
4: Select text and MMB-drag it onto a shelf of your choise, like Custom
5: If asked, select that it is Python format

Usage:
1: Press the created button
2: Select BSI file to import

Notes*
The importer script is not something we use during production as we have the source files, so it has not been tested a lot.
What use it has seen has only been in Maya 2016, but as it's all Python, it should work on newer versions that still run Python 2.7.

All BSI files in the project can't be imported with this script.
It depends on which software they where originally created in as different softwares allow different setups and some are not valid in Maya.
