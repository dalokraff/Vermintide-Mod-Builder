# Only tested with Maya 2016
# Run with importBSI() to open file picker interface.

import os
import json
import zlib

import maya.cmds as mc
import maya.OpenMaya as om
import maya.OpenMayaAnim as oma


scene_unit_converter = {'meter': 100, 'centimeter': 1, 'millimeter': 0.1}
empty_transform = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
break_on_errors = False


def _openSJSON(file_path, skip_editor_data = True):
    return_dict = {}
    try:
        with open(file_path, 'rb') as f:
            data = f.read()
            if data[:4] == 'bsiz':
                data = zlib.decompress(data[8:])
            file_lines = ['{\n']
            inside_list = False
            check_editor_data = 1 if skip_editor_data else 0
            new_data = data.decode("utf-8")
            for line in new_data.splitlines():
                if check_editor_data:
                    if check_editor_data > 1:
                        if line[0] == '}':
                            check_editor_data = 0
                        continue
                    elif line[:18] == 'editor_metadata = ':
                        check_editor_data = 2
                        continue
                if not line.strip():
                    continue
                line = line.rstrip()
                if line[-1] in ['\n', '\r']:
                    line = line[:-1]
                if ' = ' in line:
                    line_parts = line.split(' = ')
                    if '[ ' in line_parts[-1] and ' ]' in line_parts[-1]:
                        new_end = ''
                        end_parts = line_parts[-1].split(' ]')
                        short_len = len(end_parts) - 1
                        for i, end_part in enumerate(end_parts):
                            if not end_part:
                                if i < short_len:
                                    new_end += ' ]'
                                continue
                            if not '[ ' in end_part:
                                new_end += end_part + ' ]'
                                continue
                            sub_part_pre = end_part.rpartition('[ ')
                            new_end = ''.join((new_end, sub_part_pre[0], '[ ', ', '.join(sub_part_pre[-1].split(' ')), ' ]'))
                            if i < short_len and end_parts[i + 1] and end_parts[i + 1][:2] == ' [':
                                new_end += ','
                        line_parts[-1] = new_end
                    if '\t' in line_parts[0]:
                        line_start = line_parts[0].rpartition('\t')
                    else:
                        tab_len = len(line_parts[0]) - len(line_parts[0].lstrip())
                        if tab_len > 4:
                            line_start = [line_parts[0][:tab_len - 4], '' , line_parts[0].lstrip()]
                        elif tab_len > 0:
                            line_start = ['', '', line_parts[0]]
                        else:
                            line_start = line_parts[0].rpartition('\t')
                    if line_start[-1][0] == '"':
                        new_line = ''.join((''.join(line_start[:-1]), line_start[-1], ': ', ''.join(line_parts[1:])))
                    else:
                        new_line = ''.join((''.join(line_start[:-1]), '"', line_start[-1], '": ', ''.join(line_parts[1:])))
                    if not line_parts[-1][-1] == ',':
                        new_line += ','
                elif ']' in line or '}' in line:
                    new_line = line + ','
                    if '} {' in new_line:
                        new_line = new_line.replace('} {', '}, {')
                    if file_lines[-1][-2] == ',':
                        file_lines[-1] = file_lines[-1][:-2] + '\n'
                elif inside_list and not ']' in line:
                    tab_len = len(line) - len(line.lstrip())
                    new_line = line[:tab_len] + ', '.join([x for x in line[tab_len:].split(' ') if x])
                else:
                    new_line = line
                if new_line[-2:] in ['[,', '{,'] or new_line[-3:] in ['[ ,', '{ ,']:
                    new_line = new_line[:-1]
                if inside_list:
                    if ']' in line:
                        inside_list = False
                    elif not new_line[-1] in ['[', '{', ',']:
                        new_line += ','
                elif '[' in line:
                    inside_list = True
                file_lines.append(''.join(('\t', new_line.lstrip(), '\n')))
                # To save memory...
                if len(file_lines) > 100000:
                    file_lines = [''.join(file_lines)]
            if file_lines[-1][-2] == ',':
                file_lines[-1] = file_lines[-1][:-2] + '\n'
            file_lines.append('}\n')
            return_dict = json.loads(''.join(file_lines))
    except ValueError:
        print file_path.replace('\\', '/') + ': SJSON file contains a syntax error'
    return return_dict

def _mDagPathFromString(node_name):
    """ Get the API MDagPath given the name of an existing node """
    if isinstance(node_name, basestring):
        sel = om.MSelectionList()
        sel.add(node_name)
        mdag_path = om.MDagPath()
        sel.getDagPath(0, mdag_path)
        return mdag_path
    raise TypeError('Node name has to be a string -> ' + node_name)

def _vectorSub(v1, v2):
    """ Calculate v1 - v2 """
    return [v1[0] - v2[0], v1[1] - v2[1], v1[2] - v2[2]]

def _vectorMag(v):
    """ Calculate vector magnitude (length) """
    return abs((v[0] ** 2 + v[1] ** 2 + v[2] ** 2) ** 0.5)

def _checkVtxNormals(node_name, vtx):
    """ Check all vtx normals on connected faces """
    return_list = []
    vtx_face_list = []
    face_id_list = [x for x in mc.polyInfo(''.join((node_name, '.vtx[', vtx, ']')), vf = True)[0].split(' ')[:-1] if x]
    if len(face_id_list) == 2:
        mc.warning(''.join(('Bad vertex encountered, skipping normals -> ', node_name, '.vtx[', vtx, ']')))
        return []
    for i in face_id_list[2:]:
        vtx_face_list.append(''.join((node_name, '.vtxFace[', vtx, '][', i, ']')))
    last_vector = mc.polyNormalPerVertex(vtx_face_list[-1], query = True, xyz = True)
    for j in range(len(vtx_face_list) - 1):
        new_vector = mc.polyNormalPerVertex(vtx_face_list[j], query = True, xyz = True)
        if _vectorMag(_vectorSub(last_vector, new_vector)) != 0:
            return_list.append(mc.polyListComponentConversion(vtx_face_list[j], te = True)[0])
        last_vector = new_vector
    return return_list

def _unlockNormals(node_list):
    """ Unlocks normals and converts values to hard/soft edges """
    node_list = [node_list] if not isinstance(node_list, list) else node_list
    for node_name in node_list:
        hard_edge_list = []
        for i in range(mc.polyEvaluate(node_name, v = True)):
            hard_edge_list.extend(_checkVtxNormals(node_name, str(i)))
        mc.polyNormalPerVertex(node_name, ufn = True)
        mc.polySoftEdge(node_name, a = 180)
        if hard_edge_list:
            mc.polySoftEdge(hard_edge_list, a = 0)

def _locatorSize(node_name):
    mc.setAttr(node_name + '.localScaleX', 0.0005)
    mc.setAttr(node_name + '.localScaleY', 0.0005)
    mc.setAttr(node_name + '.localScaleZ', 0.0005)
    
def _createMaterial(mtrl_name):
    """ Create shading group and connected material """
    sg_node = mtrl_name + 'SG'
    mtrl_node = ''
    # If shading group doesn't exist, create it
    if not sg_node in mc.ls(type = 'shadingEngine'):
        sg_node = mc.sets(renderable = True, noSurfaceShader = True, name = sg_node, empty = True)
    if mc.connectionInfo('%s.surfaceShader' % sg_node, id = True):
        mtrl_node = mc.connectionInfo('%s.surfaceShader' % sg_node, sfd = True).split('.')[0]
    # If needed or requested, create a new material and attach it
    if not mtrl_node:
        # Delete old material if any
        if mtrl_node:
            mc.delete(mtrl_node)
        # Create material node
        mtrl_node = mc.shadingNode('blinn', asShader = True, name = mtrl_name)
        # If CGFX shader and given file of supported type, connect the file
        mc.connectAttr('%s.outColor' % mtrl_node, '%s.surfaceShader' % sg_node, f = True)
    return [sg_node, mtrl_node]

def _getUnitMultiplier():
    """ Get multiplier to use on imported data to convert to scene units """
    unit = mc.currentUnit(query = True, f = True)
    if not unit in scene_unit_converter:
        raise RuntimeError('Maya scene is set to an unsupported unit type -> ' + unit)
    return scene_unit_converter[unit]

def _addSkinCluster(node, bone_list, max_inf, node_name):
    mc.delete(node, ch = True)
    influences = ''
    # Apply the same id order for the influences
    for i in range(len(bone_list)):
        influences = influences + '"' + bone_list[i] + '", '
    print '\tAdding skinning on -> ' + node_name + ' (current name -> ' + node + ')'
    print '\tJoint count -> ' + str(len(bone_list))
    exp = 'mc.skinCluster(' + influences + ' "' + node + '", tsb=True, mi=' + str(max_inf) + ', omi=False)'
    skin_cluster = eval(exp)[0]
    sel = om.MSelectionList()
    sel.add(str(skin_cluster))
    obj = om.MObject()
    sel.getDependNode(0, obj)
    return obj, skin_cluster

def _getComponents(node):
    selectionList = om.MSelectionList()
    allComponents = om.MObject()
    selComponents = mc.polyListComponentConversion(node, ff = 1, fe = 1, fuv = 1, fvf = 1, fv = 1, tv = 1)
    sel = mc.ls(selComponents)
    mc.select(sel, r = 1)
    om.MGlobal.getActiveSelectionList(selectionList)
    selectionList.getDagPath(0, _mDagPathFromString(node), allComponents)
    mc.select(cl = True)
    return allComponents

def _applySkinWeights(node, mobj_skin_cluster, data_dict):
    # SkinCluster Node
    mfn_skin_node = oma.MFnSkinCluster(mobj_skin_cluster)
    # Mesh DAG Path
    mdagpath_mesh = _mDagPathFromString(node)
    # Mesh components
    components = _getComponents(node)
    # Influences Id's array
    inf_id_list = om.MIntArray()
    # zero weights
    zeroWeights = om.MFloatArray()
    # Weights double array
    weights = om.MFloatArray()
    # Converting the python list to the proper type
    util = om.MScriptUtil()
    util.createIntArrayFromList(data_dict['bones_id_list'], inf_id_list)
    util.createFloatArrayFromList(data_dict['zero_weights'], zeroWeights)
    util.createFloatArrayFromList(data_dict['flat_skin_weights'], weights)
    # Zero the default weights to be sure the values are clean
    mfn_skin_node.setWeights(mdagpath_mesh, components, inf_id_list, zeroWeights, True)
    # Set the stored weights
    mfn_skin_node.setWeights(mdagpath_mesh, components, inf_id_list, weights, True)

def _convertAlphaToVtxValue(alpha_ids, alpha_data, vtx_ids, converted_alpha_data):
    for i, tri in enumerate(vtx_ids):
        for j, vtx in enumerate(tri):
            converted_alpha_data[vtx] = alpha_data[alpha_ids[i][j]]
    return converted_alpha_data

def _convertColorToVtxValue(color_ids, color_data, vtx_ids, converted_color_data):
    for i, tri in enumerate(vtx_ids):
        for j, vtx in enumerate(tri):
            converted_color_data[vtx] = color_data[color_ids[i][j]]
    return converted_color_data

def _createShape(mobj_transform, geo_data, skin_dict, node_name):
    # GATHER MESH DATA
    data_dict = {}
    data_dict['vertices'] = om.MFloatPointArray()
    data_dict['polygon_counts'] = om.MIntArray()
    data_dict['polygon_connects'] = om.MIntArray()
    data_dict['normals_data'] = om.MVectorArray()
    data_dict['normals_face_ids'] = om.MIntArray()
    data_dict['uv_data'] = []
    data_dict['normals_data'] = om.MVectorArray()
    data_dict['normals_face_ids'] = om.MIntArray()
    data_dict['vertex_color_data'] = om.MColorArray()
    data_dict['vertex_color_ids'] = om.MIntArray()
    data_dict['max_skin_influence'] = 0
    data_dict['vtx_skin_weights'] = []
    data_dict['bone_influences'] = []
    tri_count = int(geo_data['indices']['size']) / 3
    temp_vtx_color_data = {}
    poly_connect_data = []
    unit_multiplier = _getUnitMultiplier()
    for i, index_stream in enumerate(geo_data['indices']['streams']):
        data_stream = geo_data['streams'][i]
        stride = data_stream['stride'] / 4
        for channel in data_stream['channels']:
            if channel['name'] == 'POSITION':
                # Get vtx data
                for vtx in [data_stream['data'][j:j + 3] for j in xrange(0, len(data_stream['data']), 3)]:
                    data_dict['vertices'].append(om.MFloatPoint(vtx[0] * unit_multiplier, vtx[1] * unit_multiplier, vtx[2] * unit_multiplier))
                # Get face data
                poly_connect_data = [index_stream[j:j + 3] for j in xrange(0, len(index_stream), 3)]
                for face in poly_connect_data:
                    data_dict['polygon_counts'].append(3)
                    for k in range(len(face)):
                        data_dict['polygon_connects'].append(face[k])
                continue
            if channel['name'] == 'TEXCOORD':
                # Get UV data
                # Channel name
                data_dict['uv_data'].append(['map' + str(channel['index'] + 1)])
                # U Values
                data_dict['uv_data'][-1].append(om.MFloatArray())
                for j in data_stream['data'][::2]:
                    data_dict['uv_data'][-1][-1].append(j)
                # V Values
                data_dict['uv_data'][-1].append(om.MFloatArray())
                for j in data_stream['data'][1::2]:
                    data_dict['uv_data'][-1][-1].append(j)
                # UV Counts
                data_dict['uv_data'][-1].append(om.MIntArray())
                for j in range(tri_count):
                    data_dict['uv_data'][-1][-1].append(3)
                # UV Ids
                data_dict['uv_data'][-1].append(om.MIntArray())
                for uvid in index_stream:
                    data_dict['uv_data'][-1][-1].append(int(uvid))
                continue
            if channel['name'] == 'NORMAL':
                # Get Normal Data
                tmp_normal_list = [data_stream['data'][j:j + 3] for j in xrange(0, len(data_stream['data']), 3)]
                index = 0
                for face_normal_ids in [index_stream[j:j + 3] for j in xrange(0, len(index_stream), 3)]:
                    for vtx_id in face_normal_ids:
                        data_dict['normals_face_ids'].append(index)
                        data_dict['normals_data'].append(om.MVector(tmp_normal_list[vtx_id][0], tmp_normal_list[vtx_id][1], tmp_normal_list[vtx_id][2]))
                    index += 1
            if channel['name'] == 'BLENDINDICES':
                # Get bones per vtx
                data_dict['max_skin_influence'] = stride
                data_dict['bone_influences'] = [data_stream['data'][j:j + stride] for j in xrange(0, len(data_stream['data']), stride)]
            if channel['name'] == 'BLENDWEIGHTS':
                # Get weight per bones per vtx
                data_dict['max_skin_influence'] = stride
                data_dict['vtx_skin_weights'] = [data_stream['data'][j:j + stride] for j in xrange(0, len(data_stream['data']), stride)]
            # VTX COLOR
            if channel['name'] == 'COLOR':
                temp_vtx_color_data['color_data'] = [data_stream['data'][j:j + 3] for j in xrange(0, len(data_stream['data']), 3)]
                temp_vtx_color_data['color_ids'] = [index_stream[j:j + 3] for j in xrange(0, len(index_stream), 3)]
            if channel['name'] == 'ALPHA':
                temp_vtx_color_data['alpha_data'] = data_stream['data']
                temp_vtx_color_data['alpha_ids'] = [index_stream[j:j + 3] for j in xrange(0, len(index_stream), 3)]
    # CREATE MESH
    mfn_mesh = om.MFnMesh()
    mfn_mesh.create(data_dict['vertices'].length(), data_dict['polygon_counts'].length(), data_dict['vertices'], data_dict['polygon_counts'], data_dict['polygon_connects'], mobj_transform)
    # Add UV data
    uv_issues = False
    for uv_set in data_dict['uv_data']:
        if not uv_issues:
            if mfn_mesh.numPolygons() == len(uv_set[3]):
                if not uv_set[0] == 'map1':
                    mfn_mesh.createUVSetWithName(uv_set[0])
                mfn_mesh.setUVs(uv_set[1], uv_set[2], uv_set[0])
                mfn_mesh.assignUVs(uv_set[3], uv_set[4], uv_set[0])
            else:
                uv_issues = True
                if break_on_errors:
                    raise RuntimeError('Could not restore UVs, colors, materials or normals due to mesh corruption during import!')
                else:
                    mc.warning('Could not restore UVs, colors, materials or normals due to mesh corruption during import!')
    # Add vertex color data
    mdagpath_transform = om.MDagPath.getAPathTo(mobj_transform)
    node = mdagpath_transform.fullPathName()
    if temp_vtx_color_data and not uv_issues:
        channel_type = ''
        color_data = [[1.0, 1.0, 1.0]] * data_dict['vertices'].length()
        if 'color_data' in temp_vtx_color_data and temp_vtx_color_data['color_data']:
            color_data = _convertColorToVtxValue(temp_vtx_color_data['color_ids'], temp_vtx_color_data['color_data'], poly_connect_data, color_data)
            channel_type += 'RGB'
        alpha_data = [1.0] * data_dict['vertices'].length()
        if 'alpha_data' in temp_vtx_color_data and temp_vtx_color_data['alpha_data']:
            alpha_data = _convertAlphaToVtxValue(temp_vtx_color_data['alpha_ids'], temp_vtx_color_data['alpha_data'], poly_connect_data, alpha_data)
            channel_type += 'A'
        for i in range(data_dict['vertices'].length()):
            data_dict['vertex_color_ids'].append(i)
            data_dict['vertex_color_data'].append(om.MColor(color_data[i][0], color_data[i][1], color_data[i][2], alpha_data[i]))
        mc.polyColorSet(node, create = True, clamped = True, rpt = channel_type, colorSet = 'bsi_imported_colors')
        mfn_mesh.setCurrentColorSetName('bsi_imported_colors')
        mfn_mesh.setVertexColors(data_dict['vertex_color_data'], data_dict['vertex_color_ids'])
    # Assign materials
    if not uv_issues:
        for mtrl in geo_data['materials']:
            mtrl_sg_node, _mtrl_node = _createMaterial(mtrl['name'])
            mc.sets(['%s.f[%d]' % (node, x) for x in mtrl['primitives']], e = True, forceElement = mtrl_sg_node)
    else:
        mc.sets(node, e = True, forceElement = 'initialShadingGroup')
    # Assign normals
    if not uv_issues:
        mfn_mesh.setFaceVertexNormals(data_dict['normals_data'], data_dict['normals_face_ids'], data_dict['polygon_connects'])
        _unlockNormals(node)
        mc.delete(node, ch = True)
    else:
        mc.polySoftEdge(node, angle = 30, ch = 0)
    # Assign skinning
    if skin_dict:
        data_dict['bones_list'] = []
        data_dict['bones_id_list'] = []
        data_dict['zero_weights'] = []
        for i, joint in enumerate([x['name'] for x in skin_dict['joints']]):
            if not mc.nodeType(joint) == 'joint':
                print '\tSkipping influence on non-joint -> ' + joint
                continue
            data_dict['bones_list'].append(joint)
            data_dict['bones_id_list'].append(i)
            data_dict['zero_weights'].append(0)
        data_dict['flat_skin_weights'] = []
        if data_dict['bones_list']:
            # Get root and temp move to origin before skinning to be able to disable inherit transformation and avoid offset issues when moving it around later.
            root_node = '|' + str(mc.ls(node, l = True)[0]).split('|')[1]
            root_node_transform = mc.xform(root_node, q=True, t=True)
            mc.xform(root_node, t=[0,0,0])
            # Create flat skin weight list
            for i, vtx_inf_list in enumerate(data_dict['bone_influences']):
                for j, joint in enumerate(data_dict['bones_list']):
                    if j in vtx_inf_list:
                        data_dict['flat_skin_weights'].append(data_dict['vtx_skin_weights'][i][vtx_inf_list.index(j)])
                    else:
                        data_dict['flat_skin_weights'].append(0)
            mobj_skin_cluster, _skin_cluster = _addSkinCluster(node, data_dict['bones_list'], data_dict['max_skin_influence'], node_name)
            _applySkinWeights(node, mobj_skin_cluster, data_dict)
            # Return root transform
            mc.setAttr(node +'.inheritsTransform', 0)
            mc.xform(root_node, t=root_node_transform)
        else:
            print '\tSkipped skinning due to no joints found as influence'
    # Refresh shape in viewport
    mfn_mesh.updateSurface()

def _key(node, frame, in_data, out_data, channel, force = False):
    if force:
        mc.setKeyframe(node, t = frame, attribute = channel)
        return
    for i in range(len(in_data)):
        if round(in_data[i], 6) == round(out_data[i], 6):
            continue
        mc.setKeyframe(node, t = frame, attribute = channel)
        return

def _transformAndKey(node, frame, transform_matrix, unit_multiplier, set_key = True, force = False):
    # Save transform to check what changed
    in_translation = mc.getAttr(node + '.translate')[0]
    in_rotation = mc.getAttr(node + '.rotate')[0]
    in_scale = mc.getAttr(node + '.scale')[0]
    # Transform
    mc.currentTime(frame, edit = True)
    _transform(node, transform_matrix, unit_multiplier)
    if set_key:
        # Set keys where there is change
        _key(node, frame, in_translation, mc.getAttr(node + '.translate')[0], 'translate', force)
        _key(node, frame, in_rotation, mc.getAttr(node + '.rotate')[0], 'rotate', force)
        _key(node, frame, in_scale, mc.getAttr(node + '.scale')[0], 'scale', force)

def _applyAnimation(node, anim_data, key_single_frame = False):
    if not anim_data['parameter'] == 'matrix':
        print '\tGot unsupported animation parameter type -> ' + anim_data['parameter']
        return
    key_data = [anim_data['stream']['data'][k:k + 16] for k in xrange(0, len(anim_data['stream']['data']), 16)]
    if not [x for x in key_data if not x == empty_transform]:
        print '\tFound empty animation, skipping keys -> ' + node
        return
    unit_multiplier = _getUnitMultiplier()
    first_key = key_data[0]
    if not [x for x in key_data if not x == first_key]:
        # Apply transform
        key_data[0][-2] = key_data[0][-2] * unit_multiplier
        key_data[0][-3] = key_data[0][-3] * unit_multiplier
        key_data[0][-4] = key_data[0][-4] * unit_multiplier
        _transformAndKey(node, 0, key_data[0], 1, set_key = key_single_frame, force = True)
        if key_single_frame:
            print '\tFound no variation in keyed data, transform applied with keys on frame 0 -> ' + node
        else:
            print '\tFound no variation in keyed data, transform applied without keys -> ' + node
        return
    for i, _time in enumerate(anim_data['times']):
        # Correct scale
        if not unit_multiplier == 1:
            key_data[i][-2] = key_data[i][-2] * unit_multiplier
            key_data[i][-3] = key_data[i][-3] * unit_multiplier
            key_data[i][-4] = key_data[i][-4] * unit_multiplier
        # Only set key if there is data and not the same as last frame
        if i == 0:
            _transformAndKey(node, i, key_data[i], 1, set_key = True, force = True)
            continue
        if key_data[i] == empty_transform or key_data[i] == key_data[i - 1]:
            continue
        _transformAndKey(node, i, key_data[i], 1, set_key = True)

def _applyAllAnimations(node_data, data_dict):
    for anim_data in data_dict.get('animations', []):
        if not anim_data['node'] in node_data:
            raise RuntimeError('Unknown node found in animation data -> ' + anim_data['node'])
        _applyAnimation(node_data[anim_data['node']], anim_data)
    mc.currentTime(0, edit = True)

def _transform(node, transform_matrix, unit_multiplier = None):
    if not unit_multiplier:
        unit_multiplier = _getUnitMultiplier()
    if not unit_multiplier == 1:
        transform_matrix[-2] = transform_matrix[-2] * unit_multiplier
        transform_matrix[-3] = transform_matrix[-3] * unit_multiplier
        transform_matrix[-4] = transform_matrix[-4] * unit_multiplier
    mc.xform(node, matrix = transform_matrix)

def _createJoint(node_name, node_dict, node_data, data_dict, joint_list, mdag_modifier, parent_joint = None):
    # Stop if not joint
    if 'geometries' in node_dict or (node_name not in joint_list and ('children' in node_dict or (not parent_joint and not parent_joint == 'root_node'))):
        if not node_name.startswith('j_'):
            return node_data
    # Create joint
    if not parent_joint or (isinstance(parent_joint, basestring) and parent_joint == 'root_node'):
        mobj_joint = mdag_modifier.createNode('joint')
    else:
        mobj_joint = mdag_modifier.createNode('joint', parent_joint)
    mdag_modifier.doIt()
    mdagpath_joint = om.MDagPath.getAPathTo(mobj_joint)
    node = mdagpath_joint.fullPathName()
    # Fix transformation
    if isinstance(parent_joint, basestring) and parent_joint == 'root_node':
        if not node_dict['parent'] in node_data:
            raise RuntimeError('Unknown parent node -> ' + node_dict['parent'])
        node = mc.parent(node, node_data[node_dict['parent']])[0]
    if 'local' in node_dict:
        _transform(node, node_dict['local'])
        mc.setAttr(node + '.jox', mc.getAttr(node + '.rx'))
        mc.setAttr(node + '.joy', mc.getAttr(node + '.ry'))
        mc.setAttr(node + '.joz', mc.getAttr(node + '.rz'))
        mc.setAttr(node + '.rx', 0)
        mc.setAttr(node + '.ry', 0)
        mc.setAttr(node + '.rz', 0)
    node_data[node_name] = mc.rename(node, node_name)
    for child in node_dict.get('children', []):
        node_data = _createJoint(child, node_dict['children'][child], node_data, data_dict, joint_list, mdag_modifier, mobj_joint)
    return node_data

def _createNode(node_name, node_dict, node_data, data_dict, joint_list):
    # Skip if joint
    if not node_name in joint_list:
        if not 'geometries' in node_dict:
            node = mc.spaceLocator()[0]
            _locatorSize(node)
        else:
            # CREATE TRANSFORM
            mfn_transform = om.MFnTransform()
            mobj_transform = mfn_transform.create()
            mdagpath_transform = om.MDagPath.getAPathTo(mobj_transform)
            node = mdagpath_transform.fullPathName()
        # Correct chain
        if 'parent' in node_dict:
            if not node_dict['parent'] in node_data:
                raise RuntimeError('Unknown parent node -> ' + node_dict['parent'])
            node = mc.parent(node, node_data[node_dict['parent']])[0]
        # Fix transformation
        if 'local' in node_dict:
            _transform(node, node_dict['local'])
        if 'geometries' in node_dict:
            # CREATE MESH
            for shape in node_dict['geometries']:
                skin_dict = {}
                if 'skins' in data_dict and shape in data_dict['skins']:
                    skin_dict = data_dict['skins'][shape]
                # Convert joint names to current scene unique node names
                if 'joints' in skin_dict:
                    for i, j in enumerate(skin_dict['joints']):
                        if not j['name'] == node_data[j['name']] :
                            print '\tUpdated joint name to unique scene name -> ' + j['name'] + ' -> ' + node_data[j['name']] 
                            j['name'] = node_data[j['name']]
                            skin_dict['joints'][i] = j
                _createShape(mobj_transform, data_dict['geometries'][shape], skin_dict, node_name)
        node_data[node_name] = mc.rename(node, node_name)
    # ADD CHILDREN
    for child in node_dict.get('children', []):
        node_data = _createNode(child, node_dict['children'][child], node_data, data_dict, joint_list)
    return node_data

def _importMesh(file_path):
    """ Import give mesh """
    data_dict = _openSJSON(file_path)
    if not 'nodes' in data_dict:
        return
    # Joint info
    joint_list = []
    if 'skins' in data_dict:
        for _k, v in data_dict['skins'].iteritems():
            for joint in v['joints']:
                if not joint['name'] in joint_list:
                    joint_list.append(joint['name'])
    # Root node
    root_node_name = data_dict['nodes'].keys()[0]
    root_node = ''
    if root_node_name in joint_list:
        mdag_modifier = om.MDagModifier()
        mobj_joint = mdag_modifier.createNode('joint')
        mdag_modifier.doIt()
        mdagpath_joint = om.MDagPath.getAPathTo(mobj_joint)
        root_node = mc.rename(mdagpath_joint.fullPathName(), root_node_name)
    else:
        root_node = mc.spaceLocator(n = root_node_name)[0]
        _locatorSize(root_node)
    _transform(root_node, data_dict['nodes'][root_node_name]['local'])
    # Check joint list for meshes
    if joint_list and 'geometries' in data_dict:
        for joint in joint_list:
            if joint in data_dict['geometries']:
                print '\tFound joint with mesh data, geometry for this node will not be imported -> ' + joint
    # Create transforms
    node_data = {root_node_name: root_node}
    # Create joints first, in case we need to skin meshes
    for node in data_dict['nodes'][root_node_name]['children']:
        if node in joint_list:
            mdag_modifier = om.MDagModifier()
            node_data = _createJoint(node, data_dict['nodes'][root_node_name]['children'][node], node_data, data_dict, joint_list, mdag_modifier, 'root_node')
    joint_list = node_data.keys()
    for node in data_dict['nodes'][root_node_name]['children']:
        node_data = _createNode(node, data_dict['nodes'][root_node_name]['children'][node], node_data, data_dict, joint_list)
    _applyAllAnimations(node_data, data_dict)
    return node_data[root_node_name], root_node_name

def importBSI():
    """ Import user selected model file into Maya """
    # Browse for file
    path = mc.fileDialog2(cap = 'Pick Model File (bsi)', fileFilter = '*.bsi', dialogStyle = 2, fileMode = 1, okc = 'Use File')
    if not path:
        return
    print 'Importing -> ' + path[0]
    _importMesh(path[0])
    # Reset all cameras
    for each_camera in mc.listCameras():
        mc.camera(each_camera, e = True, ncp = 0.1, fcp = 100000.0)
        mc.viewSet(each_camera, h = True)