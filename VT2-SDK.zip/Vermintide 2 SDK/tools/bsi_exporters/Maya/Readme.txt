Readme for Maya Bsi exporter

1: Copy the appropriate plug-ins folder for your Maya version into your Maya install directory.
2: Copy the scripts folder into your Maya install directory
3: Activate the bsi_exporter plug-in in the Maya plug-in manager
4: You should now find the option to export BSI files in the Maya export options

Notes*
When setting up your scene in Maya make sure that your has a common root transform node from which you export your scene. 
A bsi scene can have multiple roots but the first transform node will be considered your pivot point for the unit in engine.

We only support 4 joint weights per vertex. Any more than this you will have to prune, the exporter will warn you of this and which mesh is the offending mesh.

The exporter will currently crash if you try to export nodes with the same name in the same hierarchy as all nodes inside a bsi file needs to have unique names.
