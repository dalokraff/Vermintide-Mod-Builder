Readme for 3DsMax Bsi Exporter

1: Drop the dle plugin for your specific version of 3dsmax into the stdplugs folder in your 3dsmax install directory. 
2: Find the bsi file export options in the file export dialogue.

Notes*
When setting up your scene in 3DsMax make sure that your has a common root transform node from which you export your scene. 
A bsi scene can have multiple roots but the first transform node will be considered your pivot point for the unit in engine.

We only support 4 joint weights per vertex. Any more than this you will have to limit your influences per vertex count, the exporter will warn you of this and which mesh is the offending mesh.

The exporter will currently crash if you try to export nodes with the same name in the same hierarchy as all nodes inside a bsi file needs to have unique names.
