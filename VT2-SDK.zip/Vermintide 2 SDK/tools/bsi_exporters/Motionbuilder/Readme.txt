Readme for Motionbuilder Bsi Exporter

1: Copy the Motionbuilder bsi_exporter.py plugin to your Python startup folder located here: 
    *Motionbuilder install dir*\bin\config\PythonStartup
2: The Bsi exporter should now be available in the "python tools" dropdown once you start motionbuilder.
3: In your fbx scene with your animations launch the bsi exporter, select the takes you want to export and press the export button to export. 


Notes*
The motionbuilder exporter has only been tested up to Motionbuilder 2016 and might break for later versions. 
The exporter always exports everything contained within the node called root_node in your motionbuilder files. Make sure that the base node of your hiererarchy has that name and exists in the root of the scene.