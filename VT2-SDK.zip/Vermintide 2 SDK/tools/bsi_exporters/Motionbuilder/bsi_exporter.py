# Exports snapshotted data from a motion builder scene into BitSquid's
# internal data format. Each take in the scene is exported to a separate
# file in a directory selected by the user.

from pyfbsdk import FBSystem, FBApplication, FBFbxOptions, FBLabel, ShowTool, FBAddRegionParam, FBAttachType, FBImageContainer, FBList, FBFileFormatAndVersion, FBButton, FBButtonStyle, FBTextJustify, FBFolderPopup, FBFilePopup, FBFilePopupStyle, FBPlayerControl, FBTime, FBVector2d, FBVector3d, FBVector4d, FBColor, FBColorAndAlpha, FBMatrix, FBProgress, FBCamera, FBScrollBox

# These dependencies used to be named differently in previous MotionBuilder SDKs.
try:
	from pyfbsdk import FBModelTransformationType
	def fbtime_to_frames(fbtime):
		return fbtime.GetFrame()
except ImportError:
	from pyfbsdk import FBModelTransformationMatrix as FBModelTransformationType
	def fbtime_to_frames(fbtime):
		return fbtime.GetFrame(True)

try: 
	from pyfbsdk_additions import FBToolList, FBDestroyToolByName, FBCreateUniqueTool, FBHBoxLayout, FBVBoxLayout
except ImportError:
	from pyfbsdk_additions import ToolList as FBToolList, DestroyToolByName as FBDestroyToolByName, CreateUniqueTool as FBCreateUniqueTool, HBoxLayout as FBHBoxLayout, VBoxLayout as FBVBoxLayout

import re, os, os.path, sys, inspect, _winreg

# Global objects and settings
TOOL_NAME = "Bitsquid Exporter"
SYSTEM = FBSystem()
APP = FBApplication()
SCENE = FBSystem().Scene

# Utility class that lets us define enum-like classes from string literals. Typical usage:
#
# DataType = Enum(["Float", "Vector", "Matrix"])
# DataType.Vector => "Float"
class Enum(set):
	def __getattr__(self, name):
		if name in self:
			return name
		else:
			raise AttributeError
			
	def __setattr__(self, name, value):
		assert false
	
	def __delattr__(self, name):
		assert false

# Return True if the supplied value is a Python function taking the specified number of arguments.
def is_function_with_arg_count(arg_count, value):
	return hasattr(value, '__call__') and len(inspect.getargspec(value).args) == arg_count

# Class that handles updating the motion builder progress bar based on current take and frame number.
class Progress:
	def __init__(self):
		self.__progress = FBProgress()
		self.__frame_count = 0
		self.__frame = 0
	
	def begin(self, takes):
		frame_count_of = lambda take: fbtime_to_frames(take.LocalTimeSpan.GetDuration())
		self.__frame_count = sum(frame_count_of(take) for take in takes)
		self.__frame = 0
		self.__progress.ProgressBegin()
		self.__progress.Caption = "Exporting"
		self.__update_progress()
	
	def end(self):
		self.__frame_count = 0
		self.__frame = 0
		self.__update_progress()
		self.__progress.Caption = ""
		self.__progress.Text = ""
		self.__progress.ProgressDone()
	
	def begin_take(self, take):
		self.__progress.Text = take.Name
	
	def end_take(self):
		pass
		
	def begin_frame(self, frame):
		pass
	
	def end_frame(self):
		self.__frame = self.__frame + 1
		self.__update_progress()
	
	def __update_progress(self):
		if self.__frame_count == 0:
			self.__progress.Percent = 0
		else:
			progress = self.__frame / float(self.__frame_count)
			self.__progress.Percent = int(progress * 100)

# Global progress bar object
PROGRESS = Progress()


# --------------------------------------------------
# Querying and sampling the scene.
# --------------------------------------------------

# Channel types currently supported by the asset compiler / engine.
ChannelType = Enum([ "CT_FLOAT%i" % i for i in 1, 2, 3, 4 ] + [ "CT_MATRIX4x4", "CT_QUATERNION" ])

# Returns the ChannelType which is best able to represent the supplied sample value.
def channel_type_of_sample_value(value):
	assert is_supported_sample_value(value)

	if is_fbmatrix(value):
		return ChannelType.CT_MATRIX4x4

	if is_vector(value):
		vector_types_by_element_count = {
			2: ChannelType.CT_FLOAT2,
			3: ChannelType.CT_FLOAT3,
			4: ChannelType.CT_FLOAT4,
		}
		return vector_types_by_element_count[len(value)]
		
	if is_numeric(value):
		return ChannelType.CT_FLOAT1
		
	raise NotImplementedError("Unsupported value type.")

# Returns the byte stride of a single sample for a particular channel type.
def stride_of_channel_type(channel_type):
	assert channel_type in ChannelType
	
	strides = {
		ChannelType.CT_FLOAT1: 4,
		ChannelType.CT_FLOAT2: 8,
		ChannelType.CT_FLOAT3: 12,
		ChannelType.CT_FLOAT4: 16,
		ChannelType.CT_MATRIX4x4: 64,
		ChannelType.CT_QUATERNION: 16
	}
	
	return strides[channel_type]

class ChannelDeclaration:
	def __init__(self, name, channel_type):
		assert isinstance(name, basestring)
		assert channel_type in ChannelType
		self.name = name
		self.type = channel_type
		self.stride = stride_of_channel_type(channel_type)
	
	def as_obj(self, index):
		assert type(index) is int and index >= 0
		return { "index": index, "name": self.name, "type": self.type }

# Returns true if the supplied value can be an element of a sample list.
# The sample will be written to disk using the write_value() function.
# Thus, if is_supported_sample_value() yields true, is_supported_value() must also return True.
def is_supported_sample_value(value):
	is_supported = is_numeric(value) or is_vector(value) or is_fbmatrix(value)
	
	if is_supported:
		assert is_supported_value(value)
	
	return is_supported

# The AnimData structure contains enough information to animate a single parameter.
# It consists of one or more ChannelDeclarations, a list of interleaved
# samples for all channels, and a list of times for each sample.
class AnimData():
	def __init__(self, channel_declarations, interleaved_samples, times):
		assert len(channel_declarations) > 0
		assert all(isinstance(x, ChannelDeclaration) for x in channel_declarations)
		assert all(is_supported_sample_value(x) for x in interleaved_samples)
		assert all(is_numeric(x) for x in times)
		assert len(times) == len(interleaved_samples) / len(channel_declarations)
		self.channels = channel_declarations
		self.samples = interleaved_samples
		self.times = times

# A sampler calls the provider sampler function each frame,
# and appends samples to itself whenever the value differs.
#
# The function provided as sampler_func takes no parameters,
# and is expected to return a value that satisfies the
# is_supported_sample_value() function.
class Sampler():
	def __init__(self, channel_declarations, sampler_func):
		assert len(channel_declarations) > 0
		assert all(isinstance(x, ChannelDeclaration) for x in channel_declarations)
		assert is_function_with_arg_count(0, sampler_func)
		self.__channels = channel_declarations
		self.__is_multi_channel = len(channel_declarations) > 1
		self.__sampler_func = sampler_func
		self.__samples = []
		self.__times = []
		
		# If we have more than one channel, sample_func() is expected
		# to return a tuple with samples for each channel.
		if self.__is_multi_channel:
			sample = sample_func()
			assert isinstance(sample, tuple)
			assert len(sample) == len(channel_declarations)
	
	def __add_sample(self, sample, time):
		if self.__is_multi_channel:
			for element in sample:
				self.__samples.append(element)
		else:
			self.__samples.append(sample)
		
		self.__times.append(time.GetSecondDouble())
	
	def sample(self, time):
		new_sample = self.__sampler_func()
		self.__add_sample(new_sample, time)
	
	def get_anim_data(self):
		return AnimData(self.__channels, self.__samples, self.__times)

# Returns a dictionary mapping property names to newly created Sampler
# instances configured to sample those properties from the scene.
# Typically, you will get at least a Sampler for the node's local transformation matrix.
# Custom properties matching our naming pattern will also have Samplers, as well as
# certain camera-specific properties such as field of view.
def samplers_for_node(node):
	def has_matrix(node):
		return hasattr(node, "GetMatrix") and hasattr(node, "Parent")
	
	def should_export_property(property):
		return hasattr(property, "Data") and property.IsUserProperty() and re.match("^[a-z_0-9]*$", property.Name) and is_supported_sample_value(property.Data)
	
	def sample_property(property):
		assert hasattr(property, "Data")
		assert is_supported_sample_value(property.Data)
		return lambda: property.Data
	
	def sampler_for_named_property(property_name, channel_name, transform_func=None):
		property = node.PropertyList.Find(property_name)
		assert property != None
		sampler_func = transform_func == None and sample_property(property) or (lambda: transform_func(sample_property(property)()))
		channel_declarations = [ChannelDeclaration(channel_name, channel_type_of_sample_value(sampler_func()))]
		return Sampler(channel_declarations, sampler_func)
	
	samplers = {}
	
	# Any user-defined properties matching our naming pattern will be exported.
	for property in filter(should_export_property, node.PropertyList):
		sampler_func = sample_property(property)
		channel_declarations = [ChannelDeclaration(property.Name, channel_type_of_sample_value(sampler_func()))]
		samplers[property.Name] = Sampler(channel_declarations, sampler_func)
	
	# Add local transform sampler.
	if has_matrix(node):
		channel_declarations = [ChannelDeclaration("local_tm", ChannelType.CT_MATRIX4x4)]
		samplers["matrix"] = Sampler(channel_declarations, lambda: get_node_transform(node))
	
	# Add camera-specific samplers.
	if isinstance(node, FBCamera):
		samplers["yfov"] = sampler_for_named_property("FieldOfView", "yfov")
		samplers["near_clip"] = sampler_for_named_property("NearPlane", "near_clip")
		samplers["far_clip"] = sampler_for_named_property("FarPlane", "far_clip")
	
	return samplers

# Implement FBMatrix multiplication, because strangely it isn't defined in
# the autodesk 2011 SDK.
def multiply(A, B):
	Aa,Ab,Ac,Ad,Ae,Af,Ag,Ah,Ai,Aj,Ak,Al,Am,An,Ao,Ap = A[0],A[1],A[2],A[3],A[4],A[5],A[6],A[7],A[8],A[9],A[10],A[11],A[12],A[13],A[14],A[15]
	Ba,Bb,Bc,Bd,Be,Bf,Bg,Bh,Bi,Bj,Bk,Bl,Bm,Bn,Bo,Bp = B[0],B[1],B[2],B[3],B[4],B[5],B[6],B[7],B[8],B[9],B[10],B[11],B[12],B[13],B[14],B[15]
	
	C = FBMatrix()
	C[0] = Aa * Ba + Ab * Be + Ac * Bi + Ad * Bm
	C[1] = Aa * Bb + Ab * Bf + Ac * Bj + Ad * Bn
	C[2] = Aa * Bc + Ab * Bg + Ac * Bk + Ad * Bo
	C[3] = Aa * Bd + Ab * Bh + Ac * Bl + Ad * Bp
	C[4] = Ae * Ba + Af * Be + Ag * Bi + Ah * Bm
	C[5] = Ae * Bb + Af * Bf + Ag * Bj + Ah * Bn
	C[6] = Ae * Bc + Af * Bg + Ag * Bk + Ah * Bo
	C[7] = Ae * Bd + Af * Bh + Ag * Bl + Ah * Bp
	C[8] = Ai * Ba + Aj * Be + Ak * Bi + Al * Bm
	C[9] = Ai * Bb + Aj * Bf + Ak * Bj + Al * Bn
	C[10] = Ai * Bc + Aj * Bg + Ak * Bk + Al * Bo
	C[11] = Ai * Bd + Aj * Bh + Ak * Bl + Al * Bp
	C[12] = Am * Ba + An * Be + Ao * Bi + Ap * Bm
	C[13] = Am * Bb + An * Bf + Ao * Bj + Ap * Bn
	C[14] = Am * Bc + An * Bg + Ao * Bk + Ap * Bo
	C[15] = Am * Bd + An * Bh + Ao * Bl + Ap * Bp
	return C

# Gets the current local transform of the node as an FBMatrix
def get_node_transform(node):
	node_tm = FBMatrix()
	node.GetMatrix(node_tm)
	
	if not node.Parent:
		rotate = FBMatrix([-1,0,0,0,  0,0,1,0,  0,1,0,0,  0,0,0,1])
		fix = multiply(node_tm, rotate)
		return fix
	
	parent_inv_tm = FBMatrix()
	node.Parent.GetMatrix(parent_inv_tm, FBModelTransformationType.kModelInverse_Transformation)
	return multiply(node_tm, parent_inv_tm)

# Returns the animation for the take. The animation is returned as
# a dictionary in the format expected by the write_bsi() function.
# See comment for the sampled_parameters_by_node_name parameter in the write_bsi() function below.
def get_animation(take, nodes):
	SYSTEM.CurrentTake = take
	SCENE.Evaluate()
	player = FBPlayerControl()
	
	timespan = take.LocalTimeSpan
	scene_start_frame = fbtime_to_frames(timespan.GetStart())
	scene_end_frame = fbtime_to_frames(timespan.GetStop())
	frame = scene_start_frame
	player.Goto(FBTime(0, 0, 0, frame))
	
	samplers_by_node_name = dict((node.Name, samplers_for_node(node)) for node in nodes)
	
	while True:
		PROGRESS.begin_frame(frame - scene_start_frame)
		SCENE.Evaluate()
		
		for node_name, parameter_samplers in samplers_by_node_name.iteritems():
			for parameter_name, sampler in parameter_samplers.iteritems():
				sampler.sample(FBTime(0, 0, 0, frame))
				
		PROGRESS.end_frame()
		if frame >= scene_end_frame:
			break
		
		player.StepForward()
		frame = frame + 1
	
	sampled_parameters_by_node_name = {}
	
	for node_name, parameter_samplers in samplers_by_node_name.iteritems():
		anim_data_by_parameter_name = {}
		
		for parameter_name, sampler in parameter_samplers.iteritems():
			anim_data_by_parameter_name[parameter_name] = sampler.get_anim_data()
		
		sampled_parameters_by_node_name[node_name] = anim_data_by_parameter_name
	
	return sampled_parameters_by_node_name

# Returns a linear list (in breadth-first order) of all the children of the
# node root.
def get_all_children(root):
	children = [root]
	work = [root]
	
	while len(work) > 0:
		item = work.pop(0)
		for n in item.Children:
			work.append(n)
			children.append(n)
			
	return children
	
# Finds a specific node in the scene
def find_node(name):
	for item in get_all_children(SCENE.RootModel):
		if item.Name == name:
			return item
	return None

# Finds a specific take in the scene
def find_take(name):
	for item in SCENE.Takes:
		if item.Name == name:
			return item
	return None


# --------------------------------------------------
# Writing simplified JSON format.
# --------------------------------------------------

# Write indentation to the supplied output stream.
def write_indent(f, indent):
	f.write("    " * indent)

def is_dictionary(value):
	return hasattr(value, "keys") and hasattr(value, "__getitem__")

# Write a dictionary to the supplied output stream.
# Each value is prefixed by "<key> = ", and then written by calling write_value() on it.
def write_dictionary(f, indent, dictionary):
	assert is_dictionary(dictionary)
	f.write("{\n")
	sorted_keys = sorted(dictionary.keys())
	
	for key in sorted_keys:
		write_indent(f, indent + 1)
		f.write("%s = " % key)
		write_value(f, indent + 1, dictionary[key])
		f.write("\n")
	
	write_indent(f, indent)
	f.write("}")

def is_list(value):
	return not is_string(value) and not is_dictionary(value) and (hasattr(value, "__getitem__") or hasattr(value, "__iter__"))

# Write a list to the supplied output stream.
# Each element is written by calling write_value() on it.
# Line breaks are inserted after each element if the
# list looks like it would read nicer with it.
def write_list(f, indent, list):
	assert(is_list(list))
	use_line_breaks = not all(is_numeric(value) for value in list)
	separator = use_line_breaks and "\n" or " "
	value_indent = use_line_breaks and indent + 1 or 0
	f.write("[" + separator)
	
	for value in list:
		write_indent(f, value_indent)
		write_value(f, value_indent, value)
		f.write(separator)
	
	if use_line_breaks:
		write_indent(f, indent)
	
	f.write("]")

def is_fbmatrix(value):
	return isinstance(value, FBMatrix)

# Write a MotionBuilder matrix to the supplied output stream.
def write_fbmatrix(f, indent, m):
	assert(is_fbmatrix(m))
	scale = 0.01 # Assume centimeter scale
	f.write("%f %f %f %f " % (m[0], m[1], m[2], m[3]))
	f.write("%f %f %f %f " % (m[4], m[5], m[6], m[7]))
	f.write("%f %f %f %f " % (m[8], m[9], m[10], m[11]))
	f.write("  %f %f %f %f" % (m[12] * scale, m[13] * scale, m[14] * scale, m[15]))

def is_vector(value):
	return isinstance(value, (FBVector2d, FBVector3d, FBVector4d, FBColor, FBColorAndAlpha)) or (isinstance(value, tuple) and len(value) >= 2 and len(value) <= 4 and all(is_numeric(x) for x in value))

def write_vector(f, indent, vector):
	assert is_vector(vector)
	f.write(" ".join("%f" % elem for elem in vector))

def is_string(value):
	return isinstance(value, basestring)

# Write a quoted string to the supplied output stream.
def write_string(f, indent, string):
	assert is_string(string)
	f.write("\"%s\"" % string)

def is_numeric(value):
	return isinstance(value, (int, long, float, complex)) and not isinstance(value, bool)

# Write a numeric value to the supplied output stream.
def write_numeric(f, indent, n):
	assert is_numeric(n)
	if isinstance(n, float):
		f.write("%f" % n)
	else:
		f.write(str(n))

# This list defines the types of values that can be written
# to a stream using the write_value() function.
# The list is traversed in order. If the first function returns true for a supplied value,
# the second function is invoked to write the value to the output stream.
SUPPORTED_TYPES = [
	(is_fbmatrix, write_fbmatrix),
	(is_vector, write_vector),
	(is_numeric, write_numeric),
	(is_string, write_string),
	(is_dictionary, write_dictionary),
	(is_list, write_list),
]

# Returns true if the supplied value can be written to a stream using the write_value() function.
def is_supported_value(value):
	return any(can_write(value) for (can_write, write) in SUPPORTED_TYPES)
	
# Write any value to the supplied output stream.
# Elements are recursively written and indented.
# Only types declared in the SUPPORTED_TYPES list are supported.
def write_value(f, indent, value):
	if not is_supported_value(value):
		raise NotImplementedError("Unsupported value type.")
	
	for (can_write, write) in SUPPORTED_TYPES:
		if can_write(value):
			write(f, indent, value)
			return
	
	raise NotImplementedError("Unsupported value type.")

# Returns a dictionary representation of a bsi stream object.
# Typically written to disk using the write_dictionary() function.
def make_stream_obj(channel_declarations, samples):
	assert len(channel_declarations) > 0
	assert all(isinstance(x, ChannelDeclaration) for x in channel_declarations)
	assert is_list(samples)
	assert all(is_supported_sample_value(x) for x in samples)
	channel_objs = [channel_declarations[i].as_obj(i) for i in range(len(channel_declarations))]
	size = len(samples) / len(channel_declarations)
	stride = sum(channel.stride for channel in channel_declarations)
	
	obj = {
		"channels": channel_objs,
		"data": samples,
		"size": size,
		"stride": stride
	}
	
	return obj

# Returns a dictionary representation of a bsi node object.
# The bsi node object contains a bsi stream object with samples for a particular node and parameter.
# Typically written to disk using the write_dictionary() function.
def make_bsi_node_obj(node_name, parameter_name, channel_declarations, samples, times):
	assert is_string(node_name)
	assert is_string(parameter_name)
	assert len(channel_declarations) > 0
	assert is_list(times)
	assert len(times) == len(samples) / len(channel_declarations)
	
	obj = {
		"node": node_name,
		"parameter": parameter_name,
		"stream": make_stream_obj(channel_declarations, samples),
		"times": times
	}
	
	return obj


# Converts the animation to bitsquid exporter format.
# We expect sampled_parameters_by_node_name to be a dictionary mapping node names to
# a dictionary mapping parameter names to AnimData structures.
#
# Example dictionary for the sampled_parameters_by_node_name property:
# {
#   "root_point": {
#     "matrix": AnimData([ChannelDeclaration list], [FBMatrix list], [times list])
#   },
#   
#   "camera": {
#     "matrix": AnimData([ChannelDeclaration list], [FBMatrix list], [times list]),
#     "yfov": AnimData([ChannelDeclaration list], [float list], [times list]),
#     "near_clip": AnimData([ChannelDeclaration list], [float list], [times list]),
#     "far_clip": AnimData([ChannelDeclaration list], [float list], [times list]),
#     ...
#   }
# }
def write_bsi(f, sampled_parameters_by_node_name):
	f.write("animations = [\n")
	sorted_node_names = sorted(sampled_parameters_by_node_name.keys())
	
	for node_name in sorted_node_names:
		anim_data_by_parameter_name = sampled_parameters_by_node_name[node_name]
		sorted_parameter_names = sorted(anim_data_by_parameter_name.keys())
	
		for parameter_name in sorted_parameter_names:
			anim_data = anim_data_by_parameter_name[parameter_name]
			node_obj = make_bsi_node_obj(node_name, parameter_name, anim_data.channels, anim_data.samples, anim_data.times)
			write_indent(f, 1)
			write_dictionary(f, 1, node_obj)
			f.write("\n")
	
	f.write("]")


# --------------------------------------------------
# Export actions.
# --------------------------------------------------

# Exports the take to a file in the specified directory
def export_take(dir, take):
	PROGRESS.begin_take(take)
	# Find root node by name convention root_point
	root = find_node("root_point")
	exported_nodes = get_all_children(root)
	sampled_parameters_by_node_name = get_animation(take, exported_nodes)
	path = os.path.join(dir, take.Name + ".bsi")
	f = open(path, "w")
	write_bsi(f, sampled_parameters_by_node_name)
	f.close()
	PROGRESS.end_take()

# Returns true if the take should be exported.
# Returns true if the name consists of alphanumeric uncapitalized letters and underscore.
def should_export(take):
	return re.match("^[a-z_0-9]*$", take.Name)

# Exports takes as individual files in the specified directory
def export_takes(dir, takes):
	PROGRESS.begin(takes)
	for take in takes:
		export_take(dir, take)
	PROGRESS.end()

# Exports all takes as individual files in the specified directory
def export_all(dir):
	export_takes(dir, filter(should_export, SCENE.Takes))


# --------------------------------------------------
# Persiting user settings.
# --------------------------------------------------
	
def get_config_value(key, defval=None):
	try:
		cfg_root_key = _winreg.CreateKey(_winreg.HKEY_LOCAL_MACHINE, "SOFTWARE\\BitSquid\\BSIExporter\\")
		return _winreg.QueryValue(cfg_root_key, key)
	except Exception, e:
		return defval

def set_config_value(key, value):
	try:
		cfg_root_key = _winreg.CreateKey(_winreg.HKEY_LOCAL_MACHINE, "SOFTWARE\\BitSquid\\BSIExporter\\")
		_winreg.SetValue(cfg_root_key, key, _winreg.REG_SZ, value) 
		cfg_root_key.Close()
	except Exception, e:
		pass


# --------------------------------------------------
# User interface.
# --------------------------------------------------

# Creates the UI for the main dialog box
def build_ui(main):
	# Scroll box. Covers entire panel, except for the strip of buttons at the bottom.
	x = FBAddRegionParam(0, FBAttachType.kFBAttachLeft, "")
	y = FBAddRegionParam(0, FBAttachType.kFBAttachTop, "")
	w = FBAddRegionParam(0, FBAttachType.kFBAttachRight, "")
	h = FBAddRegionParam(-42, FBAttachType.kFBAttachBottom, "")
	main.AddRegion("scroll_box", "scroll_box", x, y, w, h)
	scroll_box = FBScrollBox()
	main.SetControl("scroll_box", scroll_box)
	
	# Layout containing checkboxes for each take. Nested inside the scroll box.
	x = FBAddRegionParam(0, FBAttachType.kFBAttachLeft, "")
	y = FBAddRegionParam(0, FBAttachType.kFBAttachTop, "")
	w = FBAddRegionParam(0, FBAttachType.kFBAttachRight, "")
	h = FBAddRegionParam(0, FBAttachType.kFBAttachBottom, "")
	scroll_box.Content.AddRegion("content", "content", x, y, w, h)
	checkbox_layout = FBVBoxLayout()
	scroll_box.Content.SetControl("content", checkbox_layout)
	
	# Populate our scroll box with checkboxes for each take in the scene.
	refresh_take_checkboxes(checkbox_layout, scroll_box)
	
	# Callback when the [Refresh] button is pressed.
	def refresh_callback(control, event):
		refresh_take_checkboxes(checkbox_layout, scroll_box)
	
	# Callback when the [Check All] button is pressed.
	def check_callback(control, event):
		for checkbox in [desc.control for desc in checkbox_layout.controls]:
			checkbox.State = True
	
	# Callback when the [Uncheck All] button is pressed.
	def uncheck_callback(control, event):
		for checkbox in [desc.control for desc in checkbox_layout.controls]:
			checkbox.State = False
			
	# Callback when the [Export BSI...] button is pressed.
	def export_callback(control, event):
		takes = []
		for checkbox in [desc.control for desc in checkbox_layout.controls]:
			if checkbox.State:
				for t in SCENE.Takes:
					if t.Name == checkbox.Caption:
						takes.append(t)
		
		if len(takes) == 0:
			return
		
		config = takes[0].Name
		path = get_config_value(config + "\\export_path")
		
		popup = FBFilePopup()
		popup.Caption = "Export takes to"
		popup.Filter = "*.bsi"
		popup.FileName = config + ".bsi";
		if path:
			popup.Path = os.path.dirname(path)
		popup.Style = FBFilePopupStyle.kFBFilePopupSave
		if popup.Execute():
			for t in takes:
				set_config_value(t.Name + "\\export_path", popup.FullFilename)
			dir = os.path.dirname(popup.FullFilename)
			export_takes(dir, takes)
	
	# Create button strip at the bottom of the panel.
	actions = [
		("Export BSI...", export_callback),
		("Uncheck All", uncheck_callback),
		("Check All", check_callback),
		("Refresh", refresh_callback)
	]
	
	x = FBAddRegionParam(5, FBAttachType.kFBAttachLeft, "")
	y = FBAddRegionParam(-35, FBAttachType.kFBAttachBottom, "")
	w = FBAddRegionParam(0, FBAttachType.kFBAttachRight, "")
	h = FBAddRegionParam(0, FBAttachType.kFBAttachBottom, "")
	main.AddRegion("buttons", "buttons", x, y, w, h)
	
	buttons = FBHBoxLayout(FBAttachType.kFBAttachRight)
	main.SetControl("buttons", buttons)
	
	for caption, callback in actions:
		button = FBButton()
		button.Caption = caption
		button.Width = 80
		button.Height = 30
		button.OnClick.Add(callback)
		buttons.Add(button, button.Width)
	
	label = FBLabel()
	label.Caption = "\n".join([
		"* Root point must be named 'root_point'",
		"* Assumes 30 FPS and cm scale"
	])
	
	buttons.AddRelative(label)
	return checkbox_layout, scroll_box

def refresh_take_checkboxes(checkbox_layout, scroll_box):
	take_checkbox_width = 370
	take_checkbox_height = 20
	
	checked_take_names = [desc.control.Caption for desc in checkbox_layout.controls if desc.control.State]
	checkbox_layout.RemoveAll()
	
	for take in SCENE.Takes:
		if should_export(take):
			checkbox = FBButton()
			checkbox.Caption = take.Name
			checkbox.Style = FBButtonStyle.kFBCheckbox
			checkbox.State = take.Name in checked_take_names
			checkbox_layout.Add(checkbox, take_checkbox_height, space=0)
	
	scroll_box_height = take_checkbox_height * len(checkbox_layout.controls)
	scroll_box.SetContentSize(take_checkbox_width, scroll_box_height)

# Creates the motion builder tool
def create_tool():
	t = FBCreateUniqueTool(TOOL_NAME)
	t.StartSizeX = 600
	t.StartSizeY = 600
	checkbox_layout, scroll_box = build_ui(t)
	t.OnShow.Add(lambda control, event: refresh_take_checkboxes(checkbox_layout, scroll_box))
	return t


# --------------------------------------------------
# Entry point.
# --------------------------------------------------
 
QUICK_TEST = False
DEVELOPMENT = False

if QUICK_TEST:
	take = find_take("button")
	PROGRESS.begin([take])
	export_take("D:\Work\hamilton\units", take)
	PROGRESS.end()
else:
	if DEVELOPMENT:
		FBDestroyToolByName(TOOL_NAME)
	
	if TOOL_NAME in FBToolList:
		tool = FBToolList[TOOL_NAME]
		ShowTool(tool)
	else:
		tool = create_tool()
		if DEVELOPMENT:
		   ShowTool(tool)
